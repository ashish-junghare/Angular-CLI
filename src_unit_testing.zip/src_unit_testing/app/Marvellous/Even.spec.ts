import { ChkEven } from "./Even";

describe('Check the even odd',()=>{
    it('Should return 1 if number is even',()=>{
        const ret=ChkEven(6);
        expect(ret).toBe(1);
    })

    it('Sould return 0 if number is odd',()=>{
        const ret=ChkEven(5);
        expect(ret).toBe(0);
    })
})
