import { Component } from '@angular/core';
import {FormBuilder,FormGroup,Validators, FormControl} from '@angular/forms'


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent 
{
  constructor(public fbobj : FormBuilder)
  {
  }

  MarvellousForm = this.fbobj.group(
    {
      // Add validations
      FirstName :['', Validators.required ],
      LastName : ['',Validators.required],
      EmailId : ['',Validators.required],
      PhoneNumber: ['',Validators.required],
      Adress: ['',Validators.required],
    }
  );
  
}




