import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fourth',
  templateUrl: './fourth.component.html',
  styleUrls: ['./fourth.component.css']
})
export class FourthComponent
{
  str1="Marvellous Infosystem"
  str2:string="";
  public Fun()
  {
    this.str2="Educating for better tomorrow"
    return this.str2;
  }

}
