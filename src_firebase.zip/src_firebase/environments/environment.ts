// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = 
{
  production: false,
  firebase:{
    apiKey: "AIzaSyB5KMjj7eR0SVGe1RhsYkZ21Mk3Dd2qlg0",
    authDomain: "marvellous-6b181.firebaseapp.com",
    projectId: "marvellous-6b181",
    storageBucket: "marvellous-6b181.appspot.com",
    messagingSenderId: "470633209910",
    appId: "1:470633209910:web:fcada0f22727fbd5ca3897",
    measurementId: "G-3BWJXP3WL8"
  }
  

};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
