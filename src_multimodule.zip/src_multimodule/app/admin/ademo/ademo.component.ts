import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ademo',
  templateUrl: './ademo.component.html',
  styleUrls: ['./ademo.component.css']
})
export class AdemoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
