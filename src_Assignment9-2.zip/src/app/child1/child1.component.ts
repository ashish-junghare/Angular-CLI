import { Component, OnInit } from '@angular/core';
import { NumberService } from '../number.service';

@Component({
  selector: 'app-child1',
  template: `
  <h1>
  <div *ngIf="bRet==true; else elseBlock">
    Number is prime.
  </div>
  
  <ng-template #elseBlock>
    Number is not prime.
  </ng-template>
  </h1>
  `
})
export class Child1Component implements OnInit 
{
  bRet:any;
  constructor(private _obj:NumberService) 
  { 

  }

  ngOnInit(): void 
  {
    this.bRet=this._obj.ChkPrime();
  }


}
