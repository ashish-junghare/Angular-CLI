import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NumberService 
{
  value:number;
  constructor() 
  {
    this.value=11;
  }
  ChkPrime()
  {
    var i:number=0;
    var iCnt:number=0;
    for(i=2;i<this.value;i++)
    {
        if((this.value%i)==0)
        {
            iCnt++;
        }
    }
    if(iCnt==0)
    {
      return true;
    }
    else
    {
      return false;
    }

  }
}
