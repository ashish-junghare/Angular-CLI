import { Component, OnInit } from '@angular/core';
import { StringService } from '../string.service';

@Component({
  selector: 'app-child2',
  template: `
  <h1>Number of capital letters are {{bRet}}</h1>
  
  `
})
export class Child2Component implements OnInit 
{
  bRet:any;
  constructor(private _obj:StringService) 
  {

  }

  ngOnInit(): void 
  {
    this.bRet=this._obj.CountCapital();
  }

}
