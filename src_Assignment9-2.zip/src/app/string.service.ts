import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StringService {
  str:string;
  constructor() 
  {
    this.str="AshiSh"
  }
  CountCapital()
  {
    var i:number=0;
    var count:number=0;
    for( i=0;i<this.str.length;i++)
    {
      if (this.str[i] >= "A" && this.str[i] <= "Z")
      {
          count++;
      }
     }
    return count;
  }

}
