import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'marvellousChk'
})
export class MarvellousChkPipe implements PipeTransform {

  transform(value: number,param: string): string 
  {
    var str:string="";
    if(param=="Prime")
    {
      var bFlag:boolean=false;
      var i=0,iSum=0;
      var temp=value;
      for(i=2;i<value;i++)
      {
        if(value%i==0)
        {
          bFlag=true;
        }
      }
      if(bFlag==true)
      {
        str="It is not prime number";
      }
      else
      {
        str="It is prime number";
      }
    }

    else if(param=="Perfect")
    {
      var i=0,iSum=0;
      for(i=1;i<value;i++)
      {
        if(value%i==0)
        {
          iSum=iSum+i;
        }
      }
      if(iSum==value)
      {
        str="It is perfect number";
      }
      else
      {
        str="It is not perfect number";
      }
    }

    else if(param=="Even")
    {
      if(value%2==0)
      {
        str="It is Even number";
      }
      else
      {
        str="It is not Even number";
      }
    }

    else if(param=="Odd")
    {
      if(value%2!=0)
      {
        str="It is Odd number";
      }
      else
      {
        str="It is not Odd number";
      }
    }
    
    return str;
  }
}
