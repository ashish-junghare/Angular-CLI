import { Component, OnInit } from '@angular/core';
import { ArithmeticService } from '../arithmetic.service';

@Component({
  selector: 'app-demo',
  template: `<h2>Addition is: {{sum}}</h2>
  <h2>Substraction is: {{sub}}</h2>`
})
export class DemoComponent implements OnInit 
{
  sum=0
  sub=0
  constructor(private _obj:ArithmeticService) 
  {

  }

  ngOnInit(): void 
  {
    this.sum=this._obj.Add();
    this.sub=this._obj.Sub();
  }

}
