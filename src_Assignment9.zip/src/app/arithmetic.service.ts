import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ArithmeticService {

  value1:number;
  value2:number;
  constructor() 
  {
    this.value1=21;
    this.value2=11;
  }
  Add()
  {
    var sum:number=0;
    sum=this.value1+this.value2;
    return sum
  }

  Sub()
  {
    var sub:number=0;
    sub=this.value1-this.value2;
    return sub
  }
}

