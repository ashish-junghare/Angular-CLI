import { CompSuccessDirective } from './comp-success.directive';

describe('CompSuccessDirective', () => {
  it('should create an instance', () => {
    const directive = new CompSuccessDirective();
    expect(directive).toBeTruthy();
  });
});
