import { Component } from '@angular/core';
import {FormBuilder,FormGroup,Validators, FormControl} from '@angular/forms'


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent 
{
  constructor(public fbobj : FormBuilder)
  {
  }

  MarvellousForm = this.fbobj.group(
    {
      // Add validations
      FirstName :['',Validators.required,Validators.pattern('[A-Z][a-z]*')], 
      LastName : ['',Validators.required,Validators.pattern('[A-Z][a-z]*')],
      EmailId : ['',Validators.email],
      PhoneNumber:  ['',Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")] ,
      City:['',Validators.required,Validators.minLength(4),Validators.pattern('[A-Z][a-z]*')],
      State:['',Validators.required],
      zip:['',Validators.required,Validators.minLength(5),Validators.pattern('10?|[2-9]')],
      comment:['',Validators.minLength(30)]
    }
  );
  DisplayData()
  {
    this.MarvellousForm.value(
      {
        FirstName:'',
        LastName:'',
        EmailId:'',
        PhoneNumber:'',
        City:'',
        State:'',
        zip:''

      }
    )

  }
  
  
}
