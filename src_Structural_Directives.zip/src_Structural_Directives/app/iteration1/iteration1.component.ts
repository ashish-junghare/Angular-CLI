import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-iteration1',
  templateUrl: './iteration1.component.html',
  styleUrls: ['./iteration1.component.css']
})
export class Iteration1Component
{
  public Batches=["PPA","LB","Angular","Python","LSP","Multi OS"];

}
