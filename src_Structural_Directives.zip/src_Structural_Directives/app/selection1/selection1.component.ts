import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-selection1',
  templateUrl: './selection1.component.html',
  styleUrls: ['./selection1.component.css']
})
export class Selection1Component
{
  public flag=true;
  public food=false;
}
