import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Iteration1Component } from './iteration1/iteration1.component';
import { Selection1Component } from './selection1/selection1.component';
import { Switch1Component } from './switch1/switch1.component';

@NgModule({
  declarations: [
    AppComponent,
    Iteration1Component,
    Selection1Component,
    Switch1Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
