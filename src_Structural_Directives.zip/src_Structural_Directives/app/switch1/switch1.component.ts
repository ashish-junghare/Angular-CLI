import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-switch1',
  templateUrl: './switch1.component.html',
  styleUrls: ['./switch1.component.css']
})
export class Switch1Component 
{
public Batch="Python";
}
